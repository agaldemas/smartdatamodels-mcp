# Contributors

This project is developed and maintained by:

## Core Contributors

### Alain Galdemas
- **Email**: [alain.galdemas@gmail.com](mailto:alain.galdemas@gmail.com)
- **GitHub**: [@agaldemas](https://github.com/agaldemas)
- **Role**: Project founder and lead developer

### AlainG Cline Bot
- **Email**: [alaingclinebot@gmail.com](mailto:alaingclinebot@gmail.com)
- **GitHub**: [@AlainGClineBot](https://github.com/AlainGClineBot)
- **Role**: AI-assisted development and automation
