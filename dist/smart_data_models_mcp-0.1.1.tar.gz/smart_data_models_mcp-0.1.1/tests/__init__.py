# Tests for smart-data-models-mcp
